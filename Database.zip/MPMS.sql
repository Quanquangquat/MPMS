-- Sử dụng cơ sở dữ liệu 'mpms'
USE mpms;

-- Xóa các bảng nếu đã tồn tại trước khi tạo mới
DROP TABLE IF EXISTS allocation, issue, requirement, project, user, setting;

-- Tạo bảng 'setting'
CREATE TABLE setting (
    setting_id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(50) NOT NULL,
    value VARCHAR(50),
    type_id INT,
    priority INT,
    status INT,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by_id INT,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    updated_by_id INT
);

-- Tạo bảng 'user'
CREATE TABLE user (
    user_id INT PRIMARY KEY AUTO_INCREMENT,
    full_name VARCHAR(50) NOT NULL,
    user_name VARCHAR(50) UNIQUE NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    mobile VARCHAR(15),
    password VARCHAR(100) NOT NULL,
    role_id INT,
    dep_id INT,
    start_date DATETIME,
    status INT,
    note TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by_id INT,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    updated_by_id INT
);

-- Tạo bảng 'project'
CREATE TABLE project (
    project_id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(255) NOT NULL,
    code VARCHAR(50) UNIQUE NOT NULL,
    start_date DATE,
    end_date DATE,
    dept_id INT,
    status INT,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by_id INT,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    updated_by_id INT
);

-- Tạo bảng 'allocation'
CREATE TABLE allocation (
    member_id INT,
    project_id INT,
    role_id INT,
    from_date DATE,
    to_date DATE,
    rate INT,
    description TEXT,
    status INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by_id INT,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    updated_by_id INT,
    PRIMARY KEY (member_id, project_id, role_id)
);

-- Tạo bảng 'requirement'
CREATE TABLE requirement (
    req_id INT PRIMARY KEY AUTO_INCREMENT,
    title VARCHAR(255) NOT NULL,
    owner_id INT,
    complexity_id INT,
    status_id INT,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by_id INT,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    updated_by_id INT
);

-- Tạo bảng 'issue'
CREATE TABLE issue (
    issue_id INT PRIMARY KEY AUTO_INCREMENT,
    title VARCHAR(255) NOT NULL,
    project_id INT,
    type_id INT,
    req_id INT,
    assigner_id INT,
    assignee_id INT,
    deadline DATE,
    status INT,
    status_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by_id INT,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    updated_by_id INT
);

-- Liên kết khóa ngoại
ALTER TABLE user ADD CONSTRAINT fk_user_role FOREIGN KEY (role_id) REFERENCES setting(setting_id);
ALTER TABLE project ADD CONSTRAINT fk_project_department FOREIGN KEY (dept_id) REFERENCES setting(setting_id);
ALTER TABLE allocation ADD CONSTRAINT fk_allocation_project_role FOREIGN KEY (role_id) REFERENCES setting(setting_id);
ALTER TABLE requirement ADD CONSTRAINT fk_requirement_complexity FOREIGN KEY (complexity_id) REFERENCES setting(setting_id);
ALTER TABLE requirement ADD CONSTRAINT fk_requirement_status FOREIGN KEY (status_id) REFERENCES setting(setting_id);
ALTER TABLE issue ADD CONSTRAINT fk_issue_type FOREIGN KEY (type_id) REFERENCES setting(setting_id);

-- Chèn dữ liệu vào bảng setting
INSERT INTO setting (name, value, type_id, priority, status, description, created_at, created_by_id, updated_at, updated_by_id) VALUES
('Admin', 'Administrator', 1, 1, 1, 'User role for system administrators', CURRENT_TIMESTAMP, 1, CURRENT_TIMESTAMP, 1),
('Developer', 'Developer', 1, 2, 1, 'User role for software developers', CURRENT_TIMESTAMP, 1, CURRENT_TIMESTAMP, 1),
('Project Manager', 'PM', 3, 1, 1, 'Role for project managers in project allocation', CURRENT_TIMESTAMP, 1, CURRENT_TIMESTAMP, 1),
('Team Lead', 'TL', 3, 2, 1, 'Role for team leads in project allocation', CURRENT_TIMESTAMP, 1, CURRENT_TIMESTAMP, 1),
('IT', 'Information Technology', 2, 1, 1, 'Department of IT professionals', CURRENT_TIMESTAMP, 1, CURRENT_TIMESTAMP, 1),
('HR', 'Human Resources', 2, 2, 1, 'Department of human resources', CURRENT_TIMESTAMP, 1, CURRENT_TIMESTAMP, 1),
('High Complexity', '3', 4, 1, 1, 'Complexity level for difficult requirements', CURRENT_TIMESTAMP, 1, CURRENT_TIMESTAMP, 1),
('Medium Complexity', '2', 4, 2, 1, 'Complexity level for medium difficulty requirements', CURRENT_TIMESTAMP, 1, CURRENT_TIMESTAMP, 1),
('Low Complexity', '1', 4, 3, 1, 'Complexity level for simple requirements', CURRENT_TIMESTAMP, 1, CURRENT_TIMESTAMP, 1),
('New', 'new', 5, 1, 1, 'Requirement is newly created', CURRENT_TIMESTAMP, 1, CURRENT_TIMESTAMP, 1),
('In Progress', 'in_progress', 5, 2, 1, 'Requirement is being worked on', CURRENT_TIMESTAMP, 1, CURRENT_TIMESTAMP, 1),
('Done', 'done', 5, 3, 1, 'Requirement is completed', CURRENT_TIMESTAMP, 1, CURRENT_TIMESTAMP, 1),
('Bug', 'bug', 6, 1, 1, 'Issue type for bugs', CURRENT_TIMESTAMP, 1, CURRENT_TIMESTAMP, 1),
('Feature Request', 'feature', 6, 2, 1, 'Issue type for new features', CURRENT_TIMESTAMP, 1, CURRENT_TIMESTAMP, 1);

-- Chèn dữ liệu người dùng vào bảng user
INSERT INTO user (full_name, user_name, email, mobile, password, role_id, status, note, created_at, created_by_id, updated_at, updated_by_id) VALUES
('John Doe', 'jdoe', 'john.doe@example.com', '123456789', 'password123', 1, 1, 'System Administrator', CURRENT_TIMESTAMP, 1, CURRENT_TIMESTAMP, 1),
('Jane Smith', 'jsmith', 'jane.smith@example.com', '987654321', 'password456', 2, 1, 'Lead Developer', CURRENT_TIMESTAMP, 1, CURRENT_TIMESTAMP, 1),
('Michael Brown', 'mbrown', 'michael.brown@example.com', '456789123', 'password789', 2, 0, 'Software Developer', CURRENT_TIMESTAMP, 1, CURRENT_TIMESTAMP, 1);

-- Chèn dữ liệu vào bảng project
INSERT INTO project (name, code, start_date, end_date, dept_id, status, description, created_at, created_by_id, updated_at, updated_by_id) VALUES
('Website Redesign', 'WEB-001', '2024-01-01', '2024-06-01', 5, 1, 'Redesign the company website', CURRENT_TIMESTAMP, 1, CURRENT_TIMESTAMP, 1),
('HR System Implementation', 'HR-002', '2024-02-15', '2024-07-15', 6, 0, 'Implement a new HR management system', CURRENT_TIMESTAMP, 1, CURRENT_TIMESTAMP, 1);

-- Chèn dữ liệu phân bổ vào bảng allocation
INSERT INTO allocation (member_id, project_id, role_id, from_date, to_date, rate, description, status, created_at, created_by_id, updated_at, updated_by_id) VALUES
(1, 1, 3, '2024-01-01', '2024-06-01', 100, 'John Doe is the project manager for the website redesign project', 1, CURRENT_TIMESTAMP, 1, CURRENT_TIMESTAMP, 1),
(2, 1, 4, '2024-01-01', '2024-06-01', 80, 'Jane Smith is the team lead for the website redesign project', 1, CURRENT_TIMESTAMP, 1, CURRENT_TIMESTAMP, 1),
(3, 2, 4, '2024-02-15', '2024-07-15', 100, 'Michael Brown is the team lead for the HR system implementation project', 1, CURRENT_TIMESTAMP, 1, CURRENT_TIMESTAMP, 1);

-- Chèn dữ liệu yêu cầu vào bảng requirement
INSERT INTO requirement (title, owner_id, complexity_id, status_id, description, created_at, created_by_id, updated_at, updated_by_id) VALUES
('Redesign Homepage', 2, 7, 10, 'Redesign the homepage to improve user experience', CURRENT_TIMESTAMP, 1, CURRENT_TIMESTAMP, 1),
('Implement Authentication', 2, 7, 11, 'Implement a secure authentication system for the HR project', CURRENT_TIMESTAMP, 1, CURRENT_TIMESTAMP, 1);

-- Chèn dữ liệu vấn đề vào bảng issue
INSERT INTO issue (title, type_id, req_id, assigner_id, assignee_id, deadline, status, status_date, description, created_at, created_by_id, updated_at, updated_by_id) VALUES
('Homepage Bug', 13, 1, 2, 3, '2024-03-01', 2, '2024-01-15', 'Fix the layout bug on the homepage after redesign', CURRENT_TIMESTAMP, 1, CURRENT_TIMESTAMP, 1),
('Authentication Feature Request', 14, 2, 1, 2, '2024-04-01', 1, '2024-02-20', 'Add a 2-factor authentication feature', CURRENT_TIMESTAMP, 1, CURRENT_TIMESTAMP, 1);
